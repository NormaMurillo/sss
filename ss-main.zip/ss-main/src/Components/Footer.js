import React from 'react';
import '../styles/footer.css';

const Footer = () => (
  <footer className="footer">
    © 2025 STEPS
  </footer>
);

export default Footer;
